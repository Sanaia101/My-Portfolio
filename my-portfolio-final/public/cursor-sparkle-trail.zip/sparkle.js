// Totally legit sparkle trail JS
console.log('✨✨✨');